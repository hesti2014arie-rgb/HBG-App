package com.hbg.booster

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku

private val Neon = Color(0xFF7CFF55)
private val Dark = Color(0xFF080B08)
private val Panel = Color(0xFF151B15)
private const val SHIZUKU_REQUEST_CODE = 1001

data class InstalledGame(val label: String, val packageName: String)

class MainActivity : ComponentActivity() {
    private var shizukuStatus by mutableStateOf("Checking Shizuku…")

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_REQUEST_CODE) {
                shizukuStatus = if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    "Permission granted"
                } else {
                    "Permission denied"
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        refreshShizukuStatus()

        val games = loadLaunchableApps()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Neon,
                background = Dark,
                surface = Panel,
                onPrimary = Color.Black
            )) {
                HbgDashboard(
                    games = games,
                    shizukuStatus = shizukuStatus,
                    onConnectShizuku = { connectShizuku() },
                    onRefreshShizuku = { refreshShizukuStatus() },
                    onCpuWarning = { /* warning is shown inside composable */ },
                    onLaunchGame = { packageName -> launchPackage(packageName) }
                )
            }
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun refreshShizukuStatus() {
        shizukuStatus = try {
            when {
                !Shizuku.pingBinder() -> "Shizuku is not running"
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
                    "Connected • Permission granted"
                else -> "Connected • Permission required"
            }
        } catch (_: Exception) {
            "Shizuku unavailable"
        }
    }

    private fun connectShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                shizukuStatus = "Start Shizuku first"
            } else if (Shizuku.isPreV11() /* compatibility check */) {
                shizukuStatus = "Update Shizuku"
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                shizukuStatus = "Permission already granted"
            } else {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
            }
        } catch (_: Exception) {
            shizukuStatus = "Could not request permission"
        }
    }

    private fun loadLaunchableApps(): List<InstalledGame> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { info ->
                val appInfo = info.activityInfo.applicationInfo
                val packageName = appInfo.packageName
                if (packageName == packageNameForThisApp()) null
                else InstalledGame(
                    label = info.loadLabel(packageManager).toString(),
                    packageName = packageName
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    private fun packageNameForThisApp() = applicationContext.packageName

    private fun launchPackage(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
    }
}

@Composable
private fun HbgDashboard(
    games: List<InstalledGame>,
    shizukuStatus: String,
    onConnectShizuku: () -> Unit,
    onRefreshShizuku: () -> Unit,
    onCpuWarning: () -> Unit,
    onLaunchGame: (String) -> Unit
) {
    var selectedPackage by remember { mutableStateOf<String?>(null) }
    var showCpuWarning by remember { mutableStateOf(false) }
    var antiAliasing by remember { mutableStateOf(false) }
    var msaa by remember { mutableStateOf(false) }
    var resolution by remember { mutableStateOf("Device default") }

    Surface(modifier = Modifier.fillMaxSize(), color = Dark) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("HBG", color = Neon, fontSize = 34.sp)
                Text("HELPER BOOSTER GAME", color = Color.LightGray, fontSize = 11.sp)
            }
            item {
                HbgCard {
                    Text("SHIZUKU CONNECTION", color = Neon)
                    Text(shizukuStatus, color = Color.White)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onConnectShizuku) { Text("CONNECT") }
                        OutlinedButton(onClick = onRefreshShizuku) { Text("REFRESH") }
                    }
                }
            }
            item {
                Text("GAME SELECTOR", color = Neon, fontSize = 19.sp)
                Text("Choose an installed app, then press PLAY.", color = Color.Gray, fontSize = 12.sp)
            }
            if (games.isEmpty()) {
                item { Text("No launchable apps found.", color = Color.White) }
            } else {
                items(games) { game ->
                    HbgCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(game.label, color = Color.White)
                                Text(game.packageName, color = Color.Gray, fontSize = 10.sp)
                            }
                            RadioButton(
                                selected = selectedPackage == game.packageName,
                                onClick = { selectedPackage = game.packageName },
                                colors = RadioButtonDefaults.colors(selectedColor = Neon)
                            )
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = { selectedPackage?.let(onLaunchGame) },
                    enabled = selectedPackage != null,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("PLAY SELECTED GAME") }
            }
            item { Text("GRAPHICS BOOST", color = Neon, fontSize = 19.sp) }
            item {
                HbgCard {
                    SettingSwitch("Anti-Aliasing", antiAliasing) { antiAliasing = it }
                    SettingSwitch("Force 4x MSAA (availability varies)", msaa) { msaa = it }
                    Text("Resolution", color = Color.White)
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }) {
                            Text(resolution)
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            listOf("Device default", "HD (720p)", "Full HD (1080p)").forEach {
                                DropdownMenuItem(
                                    text = { Text(it) },
                                    onClick = { resolution = it; expanded = false }
                                )
                            }
                        }
                    }
                    Text(
                        "These controls are UI preferences only in this starter build; " +
                            "they do not change system or game graphics yet.",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }
            item {
                Button(onClick = { showCpuWarning = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("CPU OPTIONS")
                }
            }
            item {
                Text("HBG • VERSION 1.0 • GRAPHICS BOOST", color = Neon, fontSize = 10.sp,
                    modifier = Modifier.fillMaxWidth())
            }
        }
    }

    if (showCpuWarning) {
        AlertDialog(
            onDismissRequest = { showCpuWarning = false },
            title = { Text("WARNING") },
            text = {
                Text("Memaksa CPU dapat meningkatkan suhu perangkat dan membuat HP panas. " +
                    "Penggunaan berlebihan dapat menyebabkan overheating. Jika ingin lanjut, " +
                    "pastikan perangkat memiliki pendinginan yang memadai.")
            },
            confirmButton = {
                TextButton(onClick = { showCpuWarning = false }) { Text("ACCEPT") }
            },
            dismissButton = {
                TextButton(onClick = { showCpuWarning = false }) { Text("CANCEL") }
            }
        )
    }
}

@Composable
private fun HbgCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(
            modifier = Modifier.padding(15.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content
        )
    }
}

@Composable
private fun SettingSwitch(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Neon)
        )
    }
}

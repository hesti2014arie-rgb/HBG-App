# HBG — Helper Booster Game

Starter Android project built with Kotlin and Jetpack Compose.

## Features in this starter
- Black + neon green dashboard
- Installed launcher-app selector
- Launch selected app
- Shizuku connection/permission status UI
- Graphics settings UI placeholders
- CPU warning confirmation dialog
- GitHub Actions debug APK workflow

## Important limitations
The graphics switches and resolution menu are UI placeholders in this starter. They do not currently change Android system settings or the graphics settings of other games. Android permissions, device vendors, Android versions, and game rendering APIs limit what a normal app can control. CPU/GPU clock forcing is not implemented.

Shizuku integration currently checks service availability and requests Shizuku permission. It does not execute privileged commands yet.

Termux is optional and is not required to build or run HBG.

## Build
Push this repository to GitHub. Open Actions → HBG Android APK Builder → Run workflow.
Download the `HBG-Android-APK` artifact after the workflow succeeds.

The workflow installs Gradle 8.13 and builds `:app:assembleDebug`.
